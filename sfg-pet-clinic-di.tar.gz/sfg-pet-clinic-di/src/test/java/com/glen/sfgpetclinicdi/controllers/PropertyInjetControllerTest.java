package com.glen.sfgpetclinicdi.controllers;

import com.glen.sfgpetclinicdi.services.GreatingServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PropertyInjetControllerTest {

    PropertyInjetController controller ;

    @BeforeEach
    void setUp() {
        controller = new PropertyInjetController();
        controller.greatingServiceImpl = new GreatingServiceImpl() ;
    }

    @Test
    void funksion() {
        System.out.println( controller.funksion() );
    }
}