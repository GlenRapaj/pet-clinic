package com.glen.sfgpetclinicdi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SfgPetClinicDiApplicationTests {

	@Test
	void contextLoads() {
	}

}
