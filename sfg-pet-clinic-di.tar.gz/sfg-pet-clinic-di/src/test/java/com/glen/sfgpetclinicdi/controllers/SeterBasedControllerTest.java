package com.glen.sfgpetclinicdi.controllers;

import com.glen.sfgpetclinicdi.services.GreatingServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SeterBasedControllerTest {

    SeterBasedController controller ;
    @BeforeEach
    void setUp() {
        controller = new SeterBasedController();
        controller.setGreatingService( new GreatingServiceImpl() );
    }

    @Test
    void getGreatingService() {
        System.out.println( controller.getGreatingService() );
    }
}