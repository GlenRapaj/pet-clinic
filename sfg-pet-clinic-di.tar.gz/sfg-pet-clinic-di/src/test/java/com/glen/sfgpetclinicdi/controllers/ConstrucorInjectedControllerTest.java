package com.glen.sfgpetclinicdi.controllers;

import com.glen.sfgpetclinicdi.services.GreatingServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ConstrucorInjectedControllerTest {

    ConstrucorInjectedController controller ;

    @BeforeEach
    void setUp() {
        controller = new ConstrucorInjectedController( new GreatingServiceImpl() );
    }

    @Test
    void getGreatingService() {
        System.out.println( controller.getGreatingService() );
    }
}