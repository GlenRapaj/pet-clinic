package com.glen.sfgpetclinicdi.controllers;

import com.glen.sfgpetclinicdi.services.GreatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

@Controller
public class SeterBasedController {

    private GreatingService greatingService ;

    @Autowired
    public void setGreatingService( @Qualifier("greatingServiceImpl") GreatingService greatingService) {

        this.greatingService = greatingService;
    }

    public String getGreatingService() {
        return greatingService.greating() ;
    }

}
