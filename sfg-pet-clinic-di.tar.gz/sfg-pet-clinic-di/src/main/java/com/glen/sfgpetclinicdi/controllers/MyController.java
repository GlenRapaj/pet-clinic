package com.glen.sfgpetclinicdi.controllers;

import com.glen.sfgpetclinicdi.services.GreatingService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {

    private GreatingService greatingService ;

    public MyController( GreatingService greatingService) {
        this.greatingService = greatingService;
    }

    // @RequestBody
   //  @RequestMapping("getSomething")
    public String getSomething(){
        // System.out.println("Hi");
        return this.greatingService.greating() ;
    }
}
