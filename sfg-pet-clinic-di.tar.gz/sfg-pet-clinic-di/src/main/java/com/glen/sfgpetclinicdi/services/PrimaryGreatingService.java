package com.glen.sfgpetclinicdi.services;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

// @Service
// @Primary
public class PrimaryGreatingService implements GreatingService{

    /*
    * Kur kemi dy beane njesoj perdorim Primary ne menyre te tille qe ti themi springut qe
    *  1 eshte kryesor ka prioritet, ndaj te tjereve.
    * */
    @Override
    public String greating() {
        return "Hi - Primary Bean";
    }

}
