package com.glen.sfgpetclinicdi.services;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Component
public class ProtoTypeBean {


    /*
    * Kemi krijuar nje bean te tipit Prototype.
    * Krijon nje objekt te ri sa here qe thirret
    * */
    public ProtoTypeBean() {
        System.out.println("Creating a prototype Bean.");
    }

    public  String getMyScope(){
        return "I am a prototype";
    }
}
