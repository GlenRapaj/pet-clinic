package com.glen.sfgpetclinicdi.services;

public interface GreatingService {

   public String greating() ;
}
