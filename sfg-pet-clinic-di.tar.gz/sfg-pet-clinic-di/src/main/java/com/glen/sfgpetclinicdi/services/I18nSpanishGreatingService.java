package com.glen.sfgpetclinicdi.services;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Profile({"ES", "default"})
@Service("i18nService")
public class I18nSpanishGreatingService implements GreatingService{


    // Nqs nuk kemi profile te tjera aktive ath. springu
    // do te marre beanet eme profile default


    /*
    * Kur Kemi me shume se nje bin qe bejne te njejten pune por per skenare te ndryshme ath. perdorim
    * @Profile("Emri qe i vendosim secilit"). Se ne cilin rast do perdoret cili psh production / development
    * specifikojme tek aplication proerties
    *
    * */

    @Override
    public String greating() {
        return "Hola - ES";
    }
}
