package com.glen.sfgpetclinicdi.services;

import org.springframework.stereotype.Service;

@Service
public class PropertyInjectedGreatingServices implements GreatingService{
    @Override
    public String greating() {
        return "Hi - Property";
    }
}
