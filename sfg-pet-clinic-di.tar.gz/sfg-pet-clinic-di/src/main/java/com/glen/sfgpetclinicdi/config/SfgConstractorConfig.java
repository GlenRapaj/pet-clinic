package com.glen.sfgpetclinicdi.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;
import org.springframework.context.annotation.Configuration;

@ConfigurationProperties("guru")
@ConstructorBinding
public class SfgConstractorConfig {

    private final String username;
    private final String jdbcurl ;
    private final  String password ;

    public SfgConstractorConfig(String username, String jdbcurl, String password) {
        this.username = username;
        this.jdbcurl = jdbcurl;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getJdbcurl() {
        return jdbcurl;
    }

    public String getPassword() {
        return password;
    }
}
