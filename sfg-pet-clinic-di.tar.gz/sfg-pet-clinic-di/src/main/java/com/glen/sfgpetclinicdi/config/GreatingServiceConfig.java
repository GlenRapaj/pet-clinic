package com.glen.sfgpetclinicdi.config;

import com.glen.sfgpetclinicdi.datasource.FakeDataSource;
import com.glen.sfgpetclinicdi.services.GreatingServiceImpl;
import com.glen.sfgpetclinicdi.services.I18nEnglishGreatingService;
import com.glen.sfgpetclinicdi.services.PrimaryGreatingService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.*;

// Lexon properties nga file specifikuar dhe te dhenat ia kalon nepermjet @Value("${guru.username}")
// @PropertySource("classpath:datasource.properties")
@EnableConfigurationProperties( SfgConstractorConfig.class )
@Configuration
public class GreatingServiceConfig {

    @Bean
    FakeDataSource fakeDataSource(@Value("${guru.username}") String username,
                                  @Value("${guru.password}") String password,
                                  @Value("${guru.jdbcurl}") String jdbcurl ){
        FakeDataSource fa = new FakeDataSource();
        fa.setJdbcurl( jdbcurl );
        fa.setPassword( password );
        fa.setUsername( username);

        return fa;
    }

    /*

    @Profile({"ES", "default"})
    @Bean("i18nService")
    I18nSpanishGreatingService i18nSpanishGreatingService(){
        return new I18nEnglishGreatingService();
    }

    @Profile("EN")
    @Bean
    I18nEnglishGreatingService i18nService(){
        return new I18nEnglishGreatingService();
    }

     */

    // @Scope  // Kur duam 1 bean me patern tjeter dhe jo singeltone qe eshte default.
    // Psh. duam prototype
    @Primary
    @Bean
    PrimaryGreatingService primaryGreatingService(){
        return new PrimaryGreatingService();
    }

    @Bean
    GreatingServiceImpl greatingServiceImpl(){
        return new GreatingServiceImpl();
    }
}
