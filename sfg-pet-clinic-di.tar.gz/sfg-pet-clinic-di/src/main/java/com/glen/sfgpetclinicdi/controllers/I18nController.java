package com.glen.sfgpetclinicdi.controllers;

import com.glen.sfgpetclinicdi.services.GreatingService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

@Controller
public class I18nController {

    private  final GreatingService greatingService ;

    public I18nController( @Qualifier("i18nService") GreatingService greatingService) {
        this.greatingService = greatingService;
    }

    public String saySomething(){
        return this.greatingService.greating() ;
    }
}
