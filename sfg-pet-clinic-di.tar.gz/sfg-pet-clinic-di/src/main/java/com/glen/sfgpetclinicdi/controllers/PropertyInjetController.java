package com.glen.sfgpetclinicdi.controllers;

import com.glen.sfgpetclinicdi.services.GreatingService;
import com.glen.sfgpetclinicdi.services.GreatingServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

@Controller
public class PropertyInjetController {

    @Autowired
    @Qualifier("propertyInjectedGreatingServices")
    public GreatingService greatingServiceImpl ;

    public  String funksion(){

        return greatingServiceImpl.greating() ;
    }
}
