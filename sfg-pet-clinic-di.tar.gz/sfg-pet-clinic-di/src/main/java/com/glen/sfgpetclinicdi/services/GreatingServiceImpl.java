package com.glen.sfgpetclinicdi.services;

import org.springframework.stereotype.Service;

// @Service
public class GreatingServiceImpl implements GreatingService {
    @Override
    public String greating() {
        return "Hi - Constructor";
    }
}
