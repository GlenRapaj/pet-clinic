package com.glen.sfgpetclinicdi.services;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Profile("EN")
@Service("i18nService")
public class I18nEnglishGreatingService implements GreatingService{
    @Override
    public String greating() {
        return "Hello - EN";
    }
}
