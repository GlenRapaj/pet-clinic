package com.glen.sfgpetclinicdi;


import com.glen.sfgpetclinicdi.config.SfgConfiguration;
import com.glen.sfgpetclinicdi.config.SfgConstractorConfig;
import com.glen.sfgpetclinicdi.controllers.*;
import com.glen.sfgpetclinicdi.datasource.FakeDataSource;
import com.glen.sfgpetclinicdi.services.ProtoTypeBean;
import com.glen.sfgpetclinicdi.services.SingeltoneBean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SfgPetClinicDiApplication {

	public static void main(String[] args) {

		// SpringApplication.run(SfgPetClinicDiApplication.class, args);
		ApplicationContext ctx = SpringApplication.run(SfgPetClinicDiApplication.class, args);

		System.out.println( "---------------Primary Bean" );
		MyController m = (MyController) ctx.getBean("myController") ;
		System.out.println( m.getSomething() );

		PropertyInjetController p = (PropertyInjetController ) ctx.getBean("propertyInjetController") ;
		System.out.println( p.funksion() );


		System.out.println( "----------------------------------seter" );
		SeterBasedController s = (SeterBasedController) ctx.getBean("seterBasedController") ;
		System.out.println( s.getGreatingService() );

		System.out.println( "-------------------------------constructor" );
		ConstrucorInjectedController c = ( ConstrucorInjectedController ) ctx.getBean("construcorInjectedController") ;
		System.out.println( c.getGreatingService() );

		System.out.println( "----------------------------------I18nController" );
		I18nController ss = (I18nController) ctx.getBean("i18nController") ;
		System.out.println( ss.saySomething() );


		System.out.println( "----------------------------------Bean Scopes" );
		SingeltoneBean singeltoneBean1 = (SingeltoneBean) ctx.getBean(SingeltoneBean.class) ;
		System.out.println(  singeltoneBean1.getMyScope()  );
		SingeltoneBean singeltoneBean2 = (SingeltoneBean) ctx.getBean(SingeltoneBean.class) ;
		System.out.println(  singeltoneBean2.getMyScope()  );


		ProtoTypeBean prototype1 = (ProtoTypeBean) ctx.getBean(ProtoTypeBean.class) ;
		System.out.println(  prototype1.getMyScope()  );
		ProtoTypeBean prototype2 = (ProtoTypeBean) ctx.getBean(ProtoTypeBean.class) ;
		System.out.println(  prototype2.getMyScope()  );

		System.out.println( "------------------Fake DataSource" );
		FakeDataSource fa = ctx.getBean(FakeDataSource.class);
		System.out.println(  fa.getUsername()  );
		System.out.println(  fa.getPassword() );
		System.out.println(  fa.getJdbcurl()  );


		System.out.println( "------------------Config Props Bean" );
		SfgConfiguration scf = ctx.getBean(SfgConfiguration.class);
		System.out.println(  scf.getUsername()  );
		System.out.println(  scf.getPassword() );
		System.out.println(  scf.getJdbcurl()  );


		System.out.println( "------------------Constructor binding" );
		SfgConstractorConfig scc = ctx.getBean(SfgConstractorConfig.class);
		System.out.println(  scc.getUsername()  );
		System.out.println(  scc.getPassword() );
		System.out.println(  scc.getJdbcurl()  );

	}

}
