package com.glen.sfgpetclinicdi.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@ConfigurationProperties("guru")
@Configuration
public class SfgConfiguration {

    private String username;
    private String jdbcurl ;
    private  String password ;

    public String getUsername() {
        return username;
    }

    public String getJdbcurl() {
        return jdbcurl;
    }

    public String getPassword() {
        return password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setJdbcurl(String jdbcurl) {
        this.jdbcurl = jdbcurl;
    }

    public void setPassword(String password) {
        this.password = password;
    }


}
