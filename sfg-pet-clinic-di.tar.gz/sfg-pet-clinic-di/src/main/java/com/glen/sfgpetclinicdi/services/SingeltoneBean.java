package com.glen.sfgpetclinicdi.services;

import org.springframework.stereotype.Component;

@Component
public class SingeltoneBean {


    public SingeltoneBean() {
        System.out.println("Creating a singeltone Bean.");
    }

    public  String getMyScope(){
        return "I am a singeltone";
    }
}
