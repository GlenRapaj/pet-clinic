package com.glen.sfgpetclinicdi.controllers;

import com.glen.sfgpetclinicdi.services.GreatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;

@Controller
public class ConstrucorInjectedController {

    private GreatingService greatingService ;

    // Emri i binit si emri i lases por fillon me shkronje te vogel
    // Perdorim @Qualifier("emri i binit qe do te injektohet") per te specifikuar se cilin do te perdorim kur kemi me shume se 1 klase
    // @Autowired // Per konstruktorin eshte opsionale autowired sepse e merr vete automatikisht
    public ConstrucorInjectedController( @Qualifier("greatingServiceImpl") GreatingService greatingService) {
        this.greatingService = greatingService;
    }

    public String getGreatingService() {
        return greatingService.greating() ;
    }
}
